﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETBAException;
using ETBA_Entities;
using System.Data.SqlClient;

namespace ETBA_DAL
{

    public class AddEmployeeDAL
    {
        static string ConnectionString = GlobalData.ConnectionString;
        SqlConnection connection = new SqlConnection();
        public bool AddEmployeDal(Users addemp)
        {
            bool isEmployeeadded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[ETBA].[SP_AddEmployee]";
                Command.Parameters.AddWithValue("@Name", addemp.Name);
                Command.Parameters.AddWithValue("@LoginId", addemp.LoginId);
                Command.Parameters.AddWithValue("@Password", addemp.Password);
                Command.Parameters.AddWithValue("@ManagerUserId", addemp.ManagerUserId);
                Command.Parameters.AddWithValue("@UserTypeId", addemp.UserTypeId);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isEmployeeadded = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return isEmployeeadded;
        }

        public bool AddManagerDal(Manager addmanager)
        {
            bool isManageradded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[ETBA].[sp_addmanager]";
                Command.Parameters.AddWithValue("@Name", addmanager.ManagerUserId);
                Command.Parameters.AddWithValue("@LoginId", addmanager.Name);
               
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isManageradded=true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return isManageradded;
        }
        public bool EditEmployee(Users editemp)
        {
            bool isemployeeedited = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[ETBA].[SP_UpdateEmployee]";
                Command.Parameters.AddWithValue("@UserId", editemp.UserId);
                Command.Parameters.AddWithValue("@Name", editemp.Name);
                Command.Parameters.AddWithValue("@LoginId", editemp.LoginId);
                Command.Parameters.AddWithValue("@Password", editemp.Password);
                Command.Parameters.AddWithValue("@ManagerUserId", editemp.ManagerUserId);
                Command.Parameters.AddWithValue("@UserTypeId", editemp.UserTypeId);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isemployeeedited = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return isemployeeedited;

        }
        public Users searchEmployeeDal(int userid)
        {
            Users name = new Users();
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[ETBA].[SP_SearchEmployee]";
                Command.Parameters.AddWithValue("@UserId", userid);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {

                        name.LoginId = Int32.Parse(Reader[2].ToString());
                        name.Name = Reader[1].ToString();
                        name.Password = Reader[3].ToString();
                        name.ManagerUserId = Int32.Parse(Reader[4].ToString());
                        name.UserTypeId = Int32.Parse(Reader[5].ToString());
                    }
                }
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return name;

        }
    }


}