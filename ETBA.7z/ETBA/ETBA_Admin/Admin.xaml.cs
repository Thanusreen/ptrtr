﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
       
        public Admin()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, RoutedEventArgs e)
        {
            //if (textBoxUserId.Text == "" && passwordBox1.Password == "")
            //{
            //    MessageBox.Show("User Id and Password Cannot be blank");
            //    textBoxUserId.Focus();
            //    return;
            //}
            //if (textBoxUserId.Text == "admin" && passwordBox1.Password == "admin")
            //{
            //    MessageBox.Show("Logged In Successfully");
            //    {
            //        AdminPowers admin = new AdminPowers();


            //        admin.Show();

            //    }
            //}
            try
            {
                SqlConnection.ConnectionString = ConnectionString;
                SqlConnection.Open();
                string query = "select Userid,Password from [ETBA].[Admin] where Userid ='" + textBoxUserId.Text + "' and Password='" + passwordBox1.Password.ToString() + "' ";
                SqlCommand cmd = new SqlCommand(query, SqlConnection);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count >= 0)
                {
                    MessageBox.Show("Login Successful");
                    AdminPowers admin = new AdminPowers();
                    admin.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password");
                }

            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                SqlConnection.Close();
            }



        }

        private void hypforget_Click(object sender, RoutedEventArgs e)
        {
            ForgotPasswordpage fgp = new ForgotPasswordpage();
            this.Content = fgp;

        }

        private void btncancel_Click(object sender, RoutedEventArgs e)
        {
            textBoxUserId.Text = string.Empty;
            passwordBox1.Clear();

        }
    }
}
