﻿using ETBA_BAL;
using ETBA_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for AdminEditEmployee.xaml
    /// </summary>
    public partial class AdminEditEmployee : Window
    {
        
        public AdminEditEmployee()
        {
            InitializeComponent();
        }

       
            private static void EditEmployee(Users editemp)
        {

            try
            {
                bool employeeadded = AddEmployeeBal.UpdateEmployeeBal(editemp);
                if (employeeadded)
                {
                    MessageBox.Show("employee edited Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Users type = new Users();
            type.UserId = Int32.Parse(txtuserid.Text);
            type.Name = txtName.Text;
            type.LoginId = Int32.Parse(txtLoginId.Text);
            type.Password = txtpswd.Text;
            type.ManagerUserId = Int32.Parse(txtManageUserId.Text);
            if (CmbUserid.Text == "Admin")
            {
                type.UserTypeId = 1;
            }
            else if (CmbUserid.Text == "Employee")
            {
                type.UserTypeId = 2;
            }
            else
            {
                type.UserTypeId = 3;
            }

         
            EditEmployee(type);
        }

        private void btnsearch_Click(object sender, RoutedEventArgs e)
        {
            int userid = Int32.Parse(txtuserid.Text.ToString());
            Users employeesearched = SearchEmployeebyId(userid);
            txtName.Text = employeesearched.Name;
            txtLoginId.Text = employeesearched.LoginId.ToString();
            txtpswd.Text = employeesearched.Password.ToString();
            txtManageUserId.Text = employeesearched.ManagerUserId.ToString();
            CmbUserid.Text = employeesearched.UserTypeId.ToString();

        }
        private static Users SearchEmployeebyId(int userid)
        {
            Users Searcheduserid = new Users();
            try
            {
                Searcheduserid = AddEmployeeBal.searchEmployeeBL(userid);
                    }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return Searcheduserid;
        }


    }
}


    