﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for AdminPowers.xaml
    /// </summary>
    public partial class AdminPowers : Window
    {
        public AdminPowers()
        {
            InitializeComponent();
        }

        
        private void AdminAddEmployee_Click(object sender, RoutedEventArgs e)
        {

            AdminAddEmployee addemp = new AdminAddEmployee();
            addemp.Show();
        }

        private void AdminEditEmployee_Click(object sender, RoutedEventArgs e)
        {
            AdminEditEmployee edtemp = new AdminEditEmployee();
            edtemp.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AdminAddManager adman = new AdminAddManager();
            adman.Show();
        }
    }
}
