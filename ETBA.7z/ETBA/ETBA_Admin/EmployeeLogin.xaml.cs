﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for EmployeeLogin.xaml
    /// </summary>
    public partial class EmployeeLogin : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        public EmployeeLogin()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SqlConnection.ConnectionString = ConnectionString;
                SqlConnection.Open();
                string query = "select Userid,Password from ETBA.Users where" +
                    " LoginId ='" + txtuserid.Text + "' and Password='" + txtpswd.Text + "' ";
                SqlCommand cmd = new SqlCommand(query, SqlConnection);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count >= 0)
                {
                    MessageBox.Show("Login Successful");
                    AdminPowers admin = new AdminPowers();
                    admin.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password");
                }

            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                SqlConnection.Close();
            }

        }

        private void ResetPasword_Click(object sender, RoutedEventArgs e)
        {
            PassWordReset PR = new PassWordReset();
            PR.Show();

        }
    }
}
