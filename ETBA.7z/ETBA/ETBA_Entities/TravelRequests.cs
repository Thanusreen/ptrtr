﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETBA_Entities
{
    class TravelRequests
    {
        public int RequestId { get; set; }
        public DateTime RequestDate { get; set; }
        public string FromLocation { get; set; }
        public string ToLocation { get; set; }
        public int UserId { get; set; }
        public string EmployeeName { get; set; }
        public int NumberofDays{ get; set; }
        public string CurrentStatus { get; set; }
        public string TravelPurpose { get; set; }
        public int ManagerUserId { get; set; }


    }
}
