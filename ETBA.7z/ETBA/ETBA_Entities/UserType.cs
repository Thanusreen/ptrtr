﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETBA_Entities
{
    public class UserType
    {
        public int UserTypeId { get; set; }
        public string Description { get; set; }
      
    }
}
