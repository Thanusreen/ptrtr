﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETBAException;
using ETBA_DAL;
using ETBA_Entities;
using System.Text.RegularExpressions;

namespace ETBA_BAL
{
    public class AddEmployeeBal
    {
        private static bool ValidateEmployee(Users newemployee)
        {
            bool isValidEmployee = true;
            StringBuilder sb = new StringBuilder();
            
            if (!Regex.Match(newemployee.LoginId.ToString(), @"^[0-9]{4}$").Success)
            {
                isValidEmployee = false;
                sb.Append(Environment.NewLine + "LoginId should not have Alphabets and Special Characters");
            }
            if (newemployee.Password.Equals(string.Empty))
            {
                isValidEmployee = false;
                sb.Append("password cannot be blank " + Environment.NewLine);

            }
            if (!(Regex.IsMatch(newemployee.ManagerUserId.ToString(), @"^[1-7]{1}$")))
            {
                isValidEmployee = false;
                sb.Append(Environment.NewLine + "ManagerUserId should be in the range of 1-7 Numbers ");
            }
            //if (!(Regex.IsMatch(newemployee.UserTypeId.ToString(), @"^[1-3]{1}$")))
            //{
            //    isValidEmployee = false;
            //    sb.Append(Environment.NewLine + "UsertypeId should be in the range of 1-3 Numbers ");
            //}


            if (newemployee.Name == string.Empty)
            {
                isValidEmployee = false;
                sb.Append(Environment.NewLine + "Employee Name Required");
            }
           
            return isValidEmployee;
        }

        public static bool AddEmployeeBL(Users addemp)
        {
            bool Personadded = false;
            try
            {
                if (ValidateEmployee (addemp))
                {
                    AddEmployeeDAL addEmployeedal = new AddEmployeeDAL();
                    Personadded = addEmployeedal.AddEmployeDal(addemp);
                }
            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Personadded;
        }
        public static bool AddManagerBL(Manager addmanager)
        {
            bool Manageradded = false;
            try
            {
                  AddEmployeeDAL addEmployeedal = new AddEmployeeDAL();
                Manageradded = addEmployeedal.AddManagerDal(addmanager);
               
            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Manageradded;
        }
        public static bool UpdateEmployeeBal(Users editemp)
        {
            bool employeeedited = false;
            try
            {
                if (ValidateEmployee(editemp))
                {
                    AddEmployeeDAL addEmployeedal = new AddEmployeeDAL();
                    employeeedited = addEmployeedal.EditEmployee(editemp);
                }
            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeedited;

        }
        public static Users searchEmployeeBL(int userid)
        {
            Users searchemployee = null;
            try
            {
                AddEmployeeDAL employeeOperations = new AddEmployeeDAL();
                searchemployee = employeeOperations.searchEmployeeDal(userid);
            }

            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return searchemployee;

        }

    }
}
